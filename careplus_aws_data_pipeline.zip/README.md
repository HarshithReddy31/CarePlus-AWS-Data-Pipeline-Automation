# CarePlus AWS Data Pipeline Project

## 📘 Overview
Developed an end-to-end automated data pipeline for **CarePlus** using AWS services. The solution ingests data from Jupyter Notebook into S3, triggers ETL processes via AWS Lambda and Glue, and stores curated data in Redshift for analytics. Power BI is used for reporting, with IAM for access control and AWS Budgets for cost monitoring.

## 🧩 Features
- Automated data ingestion from Jupyter Notebook to AWS S3  
- Event-driven ETL using AWS Lambda and Glue  
- Data warehousing with Amazon Redshift  
- Ad-hoc analytics via Athena  
- Power BI dashboard integration  
- IAM roles for security  
- AWS Budgets for cost control  

## 🏗️ Architecture
**Flow:**  
Jupyter Notebook → S3 (Raw Data) → Lambda Trigger → Glue (ETL) → S3 (Curated Data) → Redshift → Power BI

## 📂 Repository Structure
```
careplus-aws-data-pipeline/
│
├── lambda_function.py
├── glue_etl_script.py
├── jupyter_ingestion.ipynb
├── architecture_diagram.png
├── README.md
├── requirements.txt
├── LICENSE
└── sample_data/
    ├── input_data.csv
    └── transformed_data.parquet
```

## 🧠 Key Learnings
- Automating ETL pipelines with AWS Glue & Lambda  
- Managing event-based triggers via S3  
- Ensuring scalable, secure, and cost-efficient data workflows  

## 📸 Screenshot Descriptions
**Screenshot 1:** AWS Lambda function triggering Glue ETL job.  
**Screenshot 2:** AWS Glue Studio ETL visual job showing transformations.

## 📄 Short Project Summary
Automated AWS data pipeline for **CarePlus** using **Jupyter, S3, Lambda, Glue, and Redshift** to ingest, transform, and analyze data. Implemented IAM, event triggers, and budgets to ensure security and efficiency.
